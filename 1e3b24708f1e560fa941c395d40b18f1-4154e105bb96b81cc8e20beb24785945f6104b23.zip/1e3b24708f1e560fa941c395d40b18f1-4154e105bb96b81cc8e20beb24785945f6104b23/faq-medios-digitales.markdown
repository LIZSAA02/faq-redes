FAQ medios digitales
--------------------


A [Pen](https://codepen.io/Liz-A-the-flexboxer/pen/emdoBBg) by [Liz A.](https://codepen.io/Liz-A-the-flexboxer) on [CodePen](https://codepen.io).

[License](https://codepen.io/license/pen/emdoBBg).